package com.mangekyo.ability;

import com.mangekyo.entity.SusanooEntity;
import com.mangekyo.genjutsu.GenjutsuManager;
import com.mangekyo.item.MangekyoSharinganItem;
import com.mangekyo.registry.ModEntities;
import com.mangekyo.registry.ModSounds;
import com.mangekyo.util.Cooldowns;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/** Server-side logic for every Mangekyo ability. Ids match the keybinds sent from the client. */
public final class Abilities {
    public static final int TOGGLE = 0;
    public static final int SUSANOO = 1;
    public static final int TSUKUYOMI = 2;
    public static final int AMATERASU = 3;
    public static final int KAMUI = 4;
    public static final int IZANAGI = 5;

    public static final int G_WATCH = 10;
    public static final int G_CLONES = 11;
    public static final int G_ATTACK = 12;
    public static final int G_FADE = 13;
    public static final int G_SWORDS = 14;
    public static final int G_DREAM = 15;
    public static final int G_WAKE = 16;
    public static final int G_NIGHTMARE = 17;
    public static final int G_ENTER = 18;
    public static final int G_WATCHER = 19;

    private static final DustParticleOptions BLACK_FLAME =
            new DustParticleOptions(new Vector3f(0.03F, 0.0F, 0.05F), 1.8F);

    private static final Map<UUID, UUID> SUSANOO_ACTIVE = new HashMap<>();
    private static final Map<UUID, Long> IZANAGI_UNTIL = new HashMap<>();
    private static final Map<UUID, int[]> BURNING = new HashMap<>();

    private Abilities() {
    }

    // ------------------------------------------------------------------ dispatch

    public static void handle(ServerPlayer player, int id) {
        if (id == TOGGLE) {
            toggleEyes(player);
            return;
        }
        if (!wearing(player)) {
            msg(player, "Awaken the eyes first (Z).");
            return;
        }
        switch (id) {
            case SUSANOO:
                toggleSusanoo(player);
                break;
            case TSUKUYOMI:
                GenjutsuManager.cast(player);
                break;
            case AMATERASU:
                amaterasu(player);
                break;
            case KAMUI:
                kamui(player);
                break;
            case IZANAGI:
                izanagi(player);
                break;
            default:
                if (id >= G_WATCH && id <= G_WATCHER) {
                    GenjutsuManager.command(player, id);
                }
                break;
        }
    }

    public static boolean wearing(LivingEntity player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof MangekyoSharinganItem;
    }

    public static void msg(ServerPlayer player, String text) {
        player.displayClientMessage(Component.literal(text), true);
    }

    public static void sound(Entity at, SoundEvent sound, float volume, float pitch) {
        at.level().playSound(null, at.getX(), at.getY(), at.getZ(), sound, SoundSource.PLAYERS, volume, pitch);
    }

    // ------------------------------------------------------------------ Z : eyes on / off

    private static void toggleEyes(ServerPlayer player) {
        ItemStack head = player.getItemBySlot(EquipmentSlot.HEAD);
        if (head.getItem() instanceof MangekyoSharinganItem) {
            deactivateAll(player);
            player.setItemSlot(EquipmentSlot.HEAD, ItemStack.EMPTY);
            if (!player.getInventory().add(head)) {
                player.drop(head, false);
            }
            sound(player, ModSounds.SHARINGAN.get(), 0.6F, 0.6F);
            return;
        }
        Inventory inv = player.getInventory();
        int slot = -1;
        for (int i = 0; i < inv.items.size(); i++) {
            if (inv.items.get(i).getItem() instanceof MangekyoSharinganItem) {
                slot = i;
                break;
            }
        }
        if (slot < 0) {
            msg(player, "You are not carrying the Mangekyo Sharingan.");
            return;
        }
        ItemStack eyes = inv.items.get(slot);
        ItemStack oldHead = head.copy();
        inv.items.set(slot, oldHead);
        player.setItemSlot(EquipmentSlot.HEAD, eyes);
        sound(player, ModSounds.SHARINGAN.get(), 1.0F, 1.0F);
        msg(player, "Mangekyo Sharingan awakened.");
    }

    public static void deactivateAll(ServerPlayer player) {
        stopSusanoo(player);
        GenjutsuManager.endFor(player);
    }

    // ------------------------------------------------------------------ 1 : Susanoo

    public static boolean hasSusanoo(UUID id) {
        return SUSANOO_ACTIVE.containsKey(id);
    }

    public static void susanooSwing(ServerPlayer player) {
        UUID eid = SUSANOO_ACTIVE.get(player.getUUID());
        if (eid == null) {
            return;
        }
        Entity e = ((ServerLevel) player.level()).getEntity(eid);
        if (e instanceof SusanooEntity susanoo) {
            susanoo.triggerSwing();
        }
    }

    private static void toggleSusanoo(ServerPlayer player) {
        if (SUSANOO_ACTIVE.containsKey(player.getUUID())) {
            stopSusanoo(player);
            return;
        }
        if (!Cooldowns.tryUse(player, 1, 40, "Susanoo")) {
            return;
        }
        if (!player.getAbilities().instabuild && player.getFoodData().getFoodLevel() < 6) {
            msg(player, "You are too exhausted to summon Susanoo.");
            return;
        }
        UUID eid = spawnSusanoo(player);
        if (eid != null) {
            SUSANOO_ACTIVE.put(player.getUUID(), eid);
            sound(player, ModSounds.SUSANOO.get(), 1.2F, 1.0F);
        }
    }

    private static UUID spawnSusanoo(ServerPlayer player) {
        ServerLevel level = (ServerLevel) player.level();
        SusanooEntity susanoo = ModEntities.SUSANOO.get().create(level);
        if (susanoo == null) {
            return null;
        }
        susanoo.setOwner(player.getUUID());
        susanoo.moveTo(player.getX(), player.getY(), player.getZ(), player.getYRot(), 0.0F);
        level.addFreshEntity(susanoo);
        return susanoo.getUUID();
    }

    public static void stopSusanoo(ServerPlayer player) {
        UUID eid = SUSANOO_ACTIVE.remove(player.getUUID());
        if (eid != null) {
            Entity e = ((ServerLevel) player.level()).getEntity(eid);
            if (e != null) {
                e.discard();
            }
            sound(player, ModSounds.SUSANOO.get(), 0.6F, 0.5F);
        }
    }

    // ------------------------------------------------------------------ per-player upkeep

    public static void playerTick(ServerPlayer player) {
        UUID id = player.getUUID();
        if (SUSANOO_ACTIVE.containsKey(id)) {
            if (!wearing(player) || !player.isAlive()) {
                stopSusanoo(player);
            } else {
                UUID eid = SUSANOO_ACTIVE.get(id);
                ServerLevel level = (ServerLevel) player.level();
                if (eid == null || level.getEntity(eid) == null) {
                    UUID fresh = spawnSusanoo(player); // e.g. after a dimension change
                    if (fresh != null) {
                        SUSANOO_ACTIVE.put(id, fresh);
                    }
                }
                if (!player.getAbilities().instabuild) {
                    if (player.tickCount % 20 == 0) {
                        player.causeFoodExhaustion(0.4F);
                    }
                    if (player.getFoodData().getFoodLevel() <= 2) {
                        stopSusanoo(player);
                        msg(player, "Susanoo fades. You are too hungry.");
                    }
                }
            }
        }
        Long until = IZANAGI_UNTIL.get(id);
        if (until != null && until < player.level().getGameTime()) {
            IZANAGI_UNTIL.remove(id);
            msg(player, "Izanagi has faded.");
        }
    }

    // ------------------------------------------------------------------ 3 : Amaterasu

    private static void amaterasu(ServerPlayer player) {
        LivingEntity target = pickTarget(player, 48.0D);
        if (target == null) {
            msg(player, "No target in sight.");
            return;
        }
        if (!Cooldowns.tryUse(player, 3, 160, "Amaterasu")) {
            return;
        }
        BURNING.put(target.getUUID(), new int[]{600});
        sound(target, ModSounds.AMATERASU.get(), 1.4F, 1.0F);
    }

    public static void tickBurning() {
        if (BURNING.isEmpty()) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }
        Iterator<Map.Entry<UUID, int[]>> it = BURNING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, int[]> entry = it.next();
            Entity e = null;
            for (ServerLevel l : server.getAllLevels()) {
                e = l.getEntity(entry.getKey());
                if (e != null) {
                    break;
                }
            }
            if (!(e instanceof LivingEntity living) || !living.isAlive()) {
                it.remove();
                continue;
            }
            int[] ticks = entry.getValue();
            ticks[0]--;
            if (ticks[0] <= 0) {
                it.remove();
                continue;
            }
            ServerLevel level = (ServerLevel) living.level();
            if (ticks[0] % 2 == 0) {
                double w = living.getBbWidth() * 0.5D;
                double h = living.getBbHeight();
                level.sendParticles(BLACK_FLAME, living.getX(), living.getY() + h * 0.5D, living.getZ(),
                        8, w, h * 0.35D, w, 0.01D);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, living.getX(), living.getY() + h * 0.7D, living.getZ(),
                        2, w, h * 0.3D, w, 0.01D);
            }
            if (ticks[0] % 10 == 0) {
                living.invulnerableTime = 0;
                living.hurt(level.damageSources().magic(), 2.0F);
            }
        }
    }

    // ------------------------------------------------------------------ 4 : Kamui

    private static void kamui(ServerPlayer player) {
        if (!Cooldowns.tryUse(player, 4, 100, "Kamui")) {
            return;
        }
        ServerLevel level = (ServerLevel) player.level();
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = eye.add(look.scale(48.0D));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        Vec3 dest = hit.getType() == HitResult.Type.MISS ? end : hit.getLocation().subtract(look.scale(0.8D));
        double fx = dest.x;
        double fz = dest.z;
        double fy = dest.y - player.getEyeHeight();
        AABB box = player.getBoundingBox();
        for (int i = 0; i < 6; i++) {
            AABB test = box.move(fx - player.getX(), fy - player.getY(), fz - player.getZ());
            if (level.noCollision(player, test)) {
                break;
            }
            fy += 0.5D;
        }
        swirl(level, player.getX(), player.getY() + 1.0D, player.getZ());
        sound(player, ModSounds.KAMUI.get(), 1.2F, 1.0F);
        player.connection.teleport(fx, fy, fz, player.getYRot(), player.getXRot());
        swirl(level, fx, fy + 1.0D, fz);
        sound(player, ModSounds.KAMUI.get(), 1.0F, 1.3F);
    }

    private static void swirl(ServerLevel level, double x, double y, double z) {
        level.sendParticles(ParticleTypes.PORTAL, x, y, z, 50, 0.4D, 0.8D, 0.4D, 0.6D);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, x, y, z, 30, 0.3D, 0.7D, 0.3D, 0.1D);
    }

    // ------------------------------------------------------------------ 5 : Izanagi

    private static void izanagi(ServerPlayer player) {
        if (!Cooldowns.tryUse(player, 5, 6000, "Izanagi")) {
            return;
        }
        IZANAGI_UNTIL.put(player.getUUID(), player.level().getGameTime() + 1200L);
        sound(player, ModSounds.IZANAGI.get(), 1.0F, 1.0F);
        msg(player, "Izanagi: your next death will be rewritten (60s).");
    }

    /** True (and consumed) if Izanagi is active and should cancel this death. */
    public static boolean consumeIzanagi(ServerPlayer player) {
        Long until = IZANAGI_UNTIL.get(player.getUUID());
        if (until == null) {
            return false;
        }
        IZANAGI_UNTIL.remove(player.getUUID());
        return until >= player.level().getGameTime();
    }

    // ------------------------------------------------------------------ targeting

    public static LivingEntity pickTarget(ServerPlayer player, double range) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getViewVector(1.0F);
        Vec3 end = eye.add(look.scale(range));
        AABB area = player.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0D);

        BlockHitResult blockHit = player.level().clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, player));
        double blockDist = blockHit.getType() == HitResult.Type.MISS
                ? Double.MAX_VALUE : eye.distanceToSqr(blockHit.getLocation());

        LivingEntity best = null;
        double bestDist = range * range;
        for (Entity e : player.level().getEntities(player, area,
                en -> en instanceof LivingEntity && !en.isSpectator() && en.isAlive())) {
            AABB bb = e.getBoundingBox().inflate(Math.max(0.3D, e.getPickRadius()));
            Optional<Vec3> hit = bb.clip(eye, end);
            if (hit.isPresent()) {
                double d = eye.distanceToSqr(hit.get());
                if (d < bestDist && d < blockDist) {
                    bestDist = d;
                    best = (LivingEntity) e;
                }
            }
        }
        return best;
    }
}
