package com.mangekyo.ability;

/**
 * The three selector wheels shown at the side of the screen. Pure data (no client classes), shared by client and server.
 * MODE_ABILITIES: normal eyes. MODE_RED: inside a genjutsu. MODE_DREAM: the fake normal world.
 */
public final class Wheel {
    public static final int MODE_ABILITIES = 0;
    public static final int MODE_RED = 1;
    public static final int MODE_DREAM = 2;

    public static final String[] TITLES = {"MANGEKYO", "GENJUTSU", "DREAM WORLD"};

    public static final String[][] NAMES = {
            {"Susanoo", "Tsukuyomi", "Amaterasu", "Kamui", "Izanagi"},
            {"Summon Clones", "Clones Attack", "Clones Fade", "Tsukuyomi Swords", "Nightmare",
                    "Watch Eyes", "Step Inside", "Dream World", "Wake Up"},
            {"The Watcher", "Nightmare", "Tsukuyomi Swords", "Watch Eyes", "Step Inside",
                    "Red World", "Wake Up"}
    };

    public static final String[][] DESCRIPTIONS = {
            {"Blue skeleton armor", "Trap your target", "Black flames", "Warp where you look", "Undo your death"},
            {"Ring of me, staring", "They rush and punch", "They walk off, vanish", "Paralyse + sword clones",
                    "Summon a monster", "See through their eyes", "Invisible, free roam", "Fool them: fake world",
                    "End the genjutsu"},
            {"Far away, stares at them", "Summon a monster", "Paralyse + sword clones", "See through their eyes",
                    "Invisible, free roam", "Drop them in red world", "End the genjutsu"}
    };

    public static final int[][] IDS = {
            {Abilities.SUSANOO, Abilities.TSUKUYOMI, Abilities.AMATERASU, Abilities.KAMUI, Abilities.IZANAGI},
            {Abilities.G_CLONES, Abilities.G_ATTACK, Abilities.G_FADE, Abilities.G_SWORDS, Abilities.G_NIGHTMARE,
                    Abilities.G_WATCH, Abilities.G_ENTER, Abilities.G_DREAM, Abilities.G_WAKE},
            {Abilities.G_WATCHER, Abilities.G_NIGHTMARE, Abilities.G_SWORDS, Abilities.G_WATCH, Abilities.G_ENTER,
                    Abilities.G_DREAM, Abilities.G_WAKE}
    };

    private Wheel() {
    }

    public static int size(int mode) {
        return NAMES[clampMode(mode)].length;
    }

    public static int clampMode(int mode) {
        return Math.max(0, Math.min(NAMES.length - 1, mode));
    }
}
