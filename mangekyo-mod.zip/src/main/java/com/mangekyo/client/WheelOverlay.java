package com.mangekyo.client;

import com.mangekyo.ability.Wheel;
import com.mangekyo.item.MangekyoSharinganItem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/** The selector wheel on the right side of the screen. Shows the names around the selected entry. */
public final class WheelOverlay {
    private static final int[] ACCENTS = {0xFFE03030, 0xFFFF3B5C, 0xFF7FD6FF};

    public static final IGuiOverlay OVERLAY = (gui, graphics, partialTick, width, height) -> draw(graphics, width, height);

    private WheelOverlay() {
    }

    public static boolean wearingEyes(LocalPlayer player) {
        return player.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof MangekyoSharinganItem;
    }

    private static void draw(GuiGraphics g, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui || !wearingEyes(player)) {
            return;
        }
        int mode = Wheel.clampMode(ClientState.wheelMode);
        String[] names = Wheel.NAMES[mode];
        String[] descriptions = Wheel.DESCRIPTIONS[mode];
        int n = names.length;
        int selected = Math.floorMod(ClientState.wheelIndex, n);
        int accent = ACCENTS[mode];
        Font font = mc.font;

        int visible = Math.min(n, 5);
        int half = visible / 2;
        int rowH = 15;
        int panelW = 136;
        int panelH = 24 + visible * rowH + 34;
        int x = width - panelW - 6;
        int y = (height - panelH) / 2;

        g.fill(x, y, x + panelW, y + panelH, 0x99000000);
        g.fill(x, y, x + panelW, y + 1, accent);
        g.fill(x, y + panelH - 1, x + panelW, y + panelH, accent);
        g.fill(x, y, x + 1, y + panelH, accent);
        g.fill(x + panelW - 1, y, x + panelW, y + panelH, accent);

        g.drawCenteredString(font, Wheel.TITLES[mode], x + panelW / 2, y + 7, accent);

        for (int i = 0; i < visible; i++) {
            int offset = i - half;
            int index = Math.floorMod(selected + offset, n);
            int rowY = y + 22 + i * rowH;
            boolean current = offset == 0;
            if (current) {
                g.fill(x + 3, rowY - 2, x + panelW - 3, rowY + rowH - 3, (accent & 0x00FFFFFF) | 0x66000000);
                g.drawString(font, "> " + names[index], x + 8, rowY + 1, 0xFFFFFFFF);
            } else {
                int color = Math.abs(offset) == 1 ? 0xFFAAAAAA : 0xFF666666;
                g.drawString(font, names[index], x + 16, rowY + 1, color);
            }
        }

        int footerY = y + 22 + visible * rowH + 2;
        g.drawCenteredString(font, descriptions[selected], x + panelW / 2, footerY, 0xFFCCCCCC);
        String hint = ModKeys.WHEEL_NEXT.getTranslatedKeyMessage().getString() + ": scroll   "
                + ModKeys.WHEEL_USE.getTranslatedKeyMessage().getString() + ": use";
        g.drawCenteredString(font, hint, x + panelW / 2, footerY + 12, 0xFF888888);
    }
}
