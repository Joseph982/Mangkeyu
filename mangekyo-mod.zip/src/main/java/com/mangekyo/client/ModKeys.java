package com.mangekyo.client;

import com.mangekyo.ability.Abilities;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** All keybinds. Rebind any of them in Options > Controls > Mangekyo Sharingan. */
public final class ModKeys {
    /** Keys that send an ability id to the server. */
    public static final Map<KeyMapping, Integer> KEYS = new LinkedHashMap<>();
    /** Keys handled on the client (the wheel). */
    public static final List<KeyMapping> LOCAL = new ArrayList<>();

    public static final KeyMapping TOGGLE = make("toggle", GLFW.GLFW_KEY_Z, Abilities.TOGGLE);
    public static final KeyMapping ABILITY_1 = make("ability1", GLFW.GLFW_KEY_H, Abilities.SUSANOO);
    public static final KeyMapping ABILITY_2 = make("ability2", GLFW.GLFW_KEY_B, Abilities.TSUKUYOMI);
    public static final KeyMapping ABILITY_3 = make("ability3", GLFW.GLFW_KEY_I, Abilities.AMATERASU);
    public static final KeyMapping ABILITY_4 = make("kamui", GLFW.GLFW_KEY_C, Abilities.KAMUI);
    public static final KeyMapping ABILITY_5 = make("ability5", GLFW.GLFW_KEY_G, Abilities.IZANAGI);

    public static final KeyMapping WHEEL_NEXT = local("wheel_next", GLFW.GLFW_KEY_R);
    public static final KeyMapping WHEEL_USE = local("wheel_use", GLFW.GLFW_KEY_X);

    public static final KeyMapping G_WATCH = make("genjutsu_watch", GLFW.GLFW_KEY_V, Abilities.G_WATCH);
    public static final KeyMapping G_ENTER = make("genjutsu_enter", GLFW.GLFW_KEY_LEFT_BRACKET, Abilities.G_ENTER);
    public static final KeyMapping G_CLONES = make("genjutsu_clones", GLFW.GLFW_KEY_N, Abilities.G_CLONES);
    public static final KeyMapping G_ATTACK = make("genjutsu_attack", GLFW.GLFW_KEY_M, Abilities.G_ATTACK);
    public static final KeyMapping G_FADE = make("genjutsu_fade", GLFW.GLFW_KEY_U, Abilities.G_FADE);
    public static final KeyMapping G_SWORDS = make("genjutsu_swords", GLFW.GLFW_KEY_K, Abilities.G_SWORDS);
    public static final KeyMapping G_DREAM = make("genjutsu_dream", GLFW.GLFW_KEY_J, Abilities.G_DREAM);
    public static final KeyMapping G_NIGHTMARE = make("genjutsu_nightmare", GLFW.GLFW_KEY_Y, Abilities.G_NIGHTMARE);
    public static final KeyMapping G_WAKE = make("genjutsu_wake", GLFW.GLFW_KEY_O, Abilities.G_WAKE);
    public static final KeyMapping G_WATCHER = make("genjutsu_watcher", GLFW.GLFW_KEY_SEMICOLON, Abilities.G_WATCHER);

    private ModKeys() {
    }

    private static KeyMapping local(String name, int key) {
        KeyMapping mapping = new KeyMapping("key.mangekyo." + name, key, "key.categories.mangekyo");
        LOCAL.add(mapping);
        return mapping;
    }

    private static KeyMapping make(String name, int key, int abilityId) {
        KeyMapping mapping = new KeyMapping("key.mangekyo." + name, key, "key.categories.mangekyo");
        KEYS.put(mapping, abilityId);
        return mapping;
    }
}
