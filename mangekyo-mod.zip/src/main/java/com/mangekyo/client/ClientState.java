package com.mangekyo.client;

import com.mangekyo.ability.Wheel;

/** Plain client-side state (no client-only class references, safe to load anywhere). */
public final class ClientState {
    public static boolean frozen = false;
    public static float yaw = 0.0F;
    public static float pitch = 0.0F;

    public static int wheelMode = Wheel.MODE_ABILITIES;
    public static int wheelIndex = 0;

    private ClientState() {
    }

    public static void set(boolean isFrozen, float newYaw, float newPitch) {
        frozen = isFrozen;
        yaw = newYaw;
        pitch = newPitch;
    }

    /** The server switched wheels (genjutsu started / ended / stage changed): start on the first entry. */
    public static void setWheel(int mode) {
        int clamped = Wheel.clampMode(mode);
        if (clamped != wheelMode) {
            wheelMode = clamped;
            wheelIndex = 0;
        }
    }

    public static void scrollWheel(int direction) {
        int size = Wheel.size(wheelMode);
        wheelIndex = Math.floorMod(wheelIndex + direction, size);
    }

    public static int currentAbilityId() {
        int mode = Wheel.clampMode(wheelMode);
        return Wheel.IDS[mode][Math.floorMod(wheelIndex, Wheel.size(mode))];
    }

    public static void reset() {
        frozen = false;
        wheelMode = Wheel.MODE_ABILITIES;
        wheelIndex = 0;
    }
}
