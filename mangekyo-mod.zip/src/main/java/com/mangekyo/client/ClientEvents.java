package com.mangekyo.client;

import com.mangekyo.Mangekyo;
import com.mangekyo.network.AbilityPacket;
import com.mangekyo.network.ModNetwork;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Map;

@Mod.EventBusSubscriber(modid = Mangekyo.MODID, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null) {
            ClientState.reset();
            return;
        }
        if (event.phase == TickEvent.Phase.START) {
            if (ClientState.frozen) {
                player.setYRot(ClientState.yaw);
                player.setXRot(ClientState.pitch);
                player.yRotO = ClientState.yaw;
                player.xRotO = ClientState.pitch;
            }
            return;
        }
        while (ModKeys.WHEEL_NEXT.consumeClick()) {
            if (mc.screen == null && WheelOverlay.wearingEyes(player)) {
                ClientState.scrollWheel(Screen.hasShiftDown() ? -1 : 1);
                mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.UI_BUTTON_CLICK, 1.4F));
            }
        }
        while (ModKeys.WHEEL_USE.consumeClick()) {
            if (mc.screen == null && WheelOverlay.wearingEyes(player)) {
                ModNetwork.CHANNEL.sendToServer(new AbilityPacket(ClientState.currentAbilityId()));
            }
        }
        for (Map.Entry<KeyMapping, Integer> entry : ModKeys.KEYS.entrySet()) {
            while (entry.getKey().consumeClick()) {
                if (mc.screen == null) {
                    ModNetwork.CHANNEL.sendToServer(new AbilityPacket(entry.getValue()));
                }
            }
        }
    }

    /** Paralysed: no walking, no jumping. */
    @SubscribeEvent
    public static void onMovementInput(MovementInputUpdateEvent event) {
        if (ClientState.frozen) {
            event.getInput().up = false;
            event.getInput().down = false;
            event.getInput().left = false;
            event.getInput().right = false;
            event.getInput().jumping = false;
            event.getInput().shiftKeyDown = false;
            event.getInput().forwardImpulse = 0.0F;
            event.getInput().leftImpulse = 0.0F;
        }
    }

    /** Paralysed: the head cannot turn, the view is forced forward. */
    @SubscribeEvent
    public static void onCamera(ViewportEvent.ComputeCameraAngles event) {
        if (ClientState.frozen) {
            event.setYaw(ClientState.yaw);
            event.setPitch(ClientState.pitch);
        }
    }

    /** Paralysed: no attacking, no using items. */
    @SubscribeEvent
    public static void onInteract(InputEvent.InteractionKeyMappingTriggered event) {
        if (ClientState.frozen) {
            event.setCanceled(true);
            event.setSwingHand(false);
        }
    }
}
