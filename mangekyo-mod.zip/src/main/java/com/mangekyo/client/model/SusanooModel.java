package com.mangekyo.client.model;

import com.mangekyo.Mangekyo;
import com.mangekyo.entity.SusanooEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Custom 3D Susanoo: a giant skeleton ribcage with spine, skull, jaw, shoulders and long bony arms.
 * Units are model pixels (16 per block). The player stands inside the ribcage.
 */
public class SusanooModel extends EntityModel<SusanooEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(Mangekyo.MODID, "susanoo"), "main");

    private final ModelPart root;
    private final ModelPart rightArm;
    private final ModelPart rightFore;
    private final ModelPart rightHand;
    private final ModelPart leftArm;
    private final ModelPart leftFore;
    private final ModelPart leftHand;
    private final ModelPart jaw;

    public SusanooModel(ModelPart root) {
        this.root = root;
        this.rightArm = root.getChild("right_arm");
        this.rightFore = this.rightArm.getChild("right_fore");
        this.rightHand = this.rightFore.getChild("right_hand");
        this.leftArm = root.getChild("left_arm");
        this.leftFore = this.leftArm.getChild("left_fore");
        this.leftHand = this.leftFore.getChild("left_hand");
        this.jaw = root.getChild("jaw");
    }

    /** Adds a box whose top face is topH pixels above the ground; model y=24 is the ground. */
    private static PartDefinition box(PartDefinition parent, String name, float cx, float topH, float cz,
                                      float w, float h, float d, int u, int v) {
        return parent.addOrReplaceChild(name,
                CubeListBuilder.create().texOffs(u, v).addBox(-w / 2.0F, 0.0F, -d / 2.0F, w, h, d),
                PartPose.offset(cx, 24.0F - topH, cz));
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // pelvis and spine (behind the player's back)
        box(root, "pelvis", 0.0F, 17.0F, 2.0F, 22.0F, 5.0F, 12.0F, 0, 0);
        box(root, "spine", 0.0F, 50.0F, 9.0F, 4.0F, 34.0F, 4.0F, 0, 0);
        box(root, "sternum", 0.0F, 40.0F, -12.5F, 3.0F, 24.0F, 2.0F, 0, 0);

        // ribs: left bar, right bar and a front bar at each height
        float[] ribHeights = {16.0F, 20.0F, 24.0F, 28.0F, 32.0F, 36.0F, 40.0F};
        for (int i = 0; i < ribHeights.length; i++) {
            float h = ribHeights[i];
            float spread = 14.0F - Math.abs(i - 3) * 0.9F; // slightly barrel shaped
            box(root, "rib_l_" + i, -spread, h, -1.5F, 1.6F, 1.6F, 22.0F, 0, 0);
            box(root, "rib_r_" + i, spread, h, -1.5F, 1.6F, 1.6F, 22.0F, 0, 0);
            box(root, "rib_f_" + i, 0.0F, h, -12.5F, spread * 2.0F, 1.6F, 1.6F, 0, 0);
        }

        // shoulders and shoulder blades
        box(root, "clavicle", 0.0F, 43.0F, -2.0F, 54.0F, 3.0F, 4.0F, 0, 0);
        box(root, "blade_l", -10.0F, 42.0F, 8.0F, 10.0F, 12.0F, 2.0F, 0, 0);
        box(root, "blade_r", 10.0F, 42.0F, 8.0F, 10.0F, 12.0F, 2.0F, 0, 0);

        // skull (own texture area with the face painted on it) and jaw
        box(root, "skull", 0.0F, 66.0F, 3.0F, 16.0F, 15.0F, 17.0F, 0, 64);
        box(root, "jaw", 0.0F, 51.0F, 0.0F, 12.0F, 5.0F, 11.0F, 66, 64);
        box(root, "neck", 0.0F, 52.0F, 7.0F, 5.0F, 8.0F, 5.0F, 0, 0);

        // arms: upper arm, forearm, hand with fingers
        buildArm(root, "right", 27.0F);
        buildArm(root, "left", -27.0F);

        return LayerDefinition.create(mesh, 128, 128);
    }

    private static void buildArm(PartDefinition root, String side, float x) {
        float zRot = x > 0 ? -0.22F : 0.22F;
        PartDefinition arm = root.addOrReplaceChild(side + "_arm",
                CubeListBuilder.create().texOffs(0, 0).addBox(-3.0F, 0.0F, -3.0F, 6.0F, 24.0F, 6.0F),
                PartPose.offsetAndRotation(x, 24.0F - 42.0F, -2.0F, -0.5F, 0.0F, zRot));
        PartDefinition fore = arm.addOrReplaceChild(side + "_fore",
                CubeListBuilder.create().texOffs(0, 0).addBox(-2.5F, 0.0F, -2.5F, 5.0F, 22.0F, 5.0F),
                PartPose.offsetAndRotation(0.0F, 24.0F, 0.0F, -0.7F, 0.0F, 0.0F));
        PartDefinition hand = fore.addOrReplaceChild(side + "_hand",
                CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, 0.0F, -1.5F, 8.0F, 6.0F, 3.0F),
                PartPose.offsetAndRotation(0.0F, 22.0F, 0.0F, 0.2F, 0.0F, 0.0F));
        float[] fx = {-3.0F, -1.0F, 1.0F, 3.0F};
        for (int i = 0; i < fx.length; i++) {
            hand.addOrReplaceChild(side + "_finger_" + i,
                    CubeListBuilder.create().texOffs(0, 0).addBox(-0.8F, 0.0F, -0.8F, 1.6F, 8.0F, 1.6F),
                    PartPose.offsetAndRotation(fx[i], 6.0F, 0.0F, 0.15F, 0.0F, 0.0F));
        }
        hand.addOrReplaceChild(side + "_thumb",
                CubeListBuilder.create().texOffs(0, 0).addBox(-0.8F, 0.0F, -0.8F, 1.6F, 5.0F, 1.6F),
                PartPose.offsetAndRotation(x > 0 ? -4.0F : 4.0F, 1.0F, -1.0F, -0.6F, 0.0F, x > 0 ? 0.7F : -0.7F));
    }

    @Override
    public void setupAnim(SusanooEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks,
                          float netHeadYaw, float headPitch) {
        float bob = Mth.sin(ageInTicks * 0.08F) * 0.04F;
        int swingTicks = entity.getSwingTicks();
        float swing = 0.0F;
        if (swingTicks > 0) {
            float progress = 1.0F - (swingTicks / 10.0F);
            swing = Mth.sin(progress * (float) Math.PI);
        }
        this.rightArm.xRot = -0.5F + bob - swing * 1.4F;
        this.rightFore.xRot = -0.7F - swing * 0.6F;
        this.rightHand.xRot = 0.2F + Mth.sin(ageInTicks * 0.15F) * 0.05F;
        this.leftArm.xRot = -0.5F - bob;
        this.leftFore.xRot = -0.7F;
        this.leftHand.xRot = 0.2F + Mth.sin(ageInTicks * 0.15F + 1.0F) * 0.05F;
        this.jaw.xRot = 0.08F + (Mth.sin(ageInTicks * 0.05F) + 1.0F) * 0.04F;
        this.root.y = Mth.sin(ageInTicks * 0.06F) * 1.2F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
