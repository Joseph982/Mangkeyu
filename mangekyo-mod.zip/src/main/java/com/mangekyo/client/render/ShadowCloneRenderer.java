package com.mangekyo.client.render;

import com.mangekyo.entity.ShadowCloneEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.ResourceLocation;

import java.util.UUID;

/** Renders a clone / frozen body as a player model wearing the skin of whoever it copies. */
public class ShadowCloneRenderer extends HumanoidMobRenderer<ShadowCloneEntity, PlayerModel<ShadowCloneEntity>> {

    public ShadowCloneRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5F);
        this.addLayer(new SharinganEyesLayer<>(this, entity -> true));
    }

    @Override
    public ResourceLocation getTextureLocation(ShadowCloneEntity entity) {
        UUID id = entity.getSkinOwner();
        if (id == null) {
            return DefaultPlayerSkin.getDefaultSkin();
        }
        ClientPacketListener connection = Minecraft.getInstance().getConnection();
        PlayerInfo info = connection == null ? null : connection.getPlayerInfo(id);
        return info != null ? info.getSkinLocation() : DefaultPlayerSkin.getDefaultSkin(id);
    }
}
