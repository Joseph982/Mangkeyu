package com.mangekyo.client.render;

import com.mangekyo.Mangekyo;
import com.mangekyo.client.model.SusanooModel;
import com.mangekyo.entity.SusanooEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import java.util.UUID;

/** Draws the Susanoo glued to its owner using the owner's interpolated position, so it never lags behind. */
public class SusanooRenderer extends EntityRenderer<SusanooEntity> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Mangekyo.MODID, "textures/entity/susanoo.png");

    private final SusanooModel model;

    public SusanooRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new SusanooModel(context.bakeLayer(SusanooModel.LAYER));
        this.shadowRadius = 0.0F;
    }

    @Override
    public ResourceLocation getTextureLocation(SusanooEntity entity) {
        return TEXTURE;
    }

    @Override
    public boolean shouldRender(SusanooEntity entity, Frustum frustum, double camX, double camY, double camZ) {
        return true;
    }

    @Override
    public void render(SusanooEntity entity, float entityYaw, float partialTick, PoseStack poseStack,
                       MultiBufferSource buffer, int packedLight) {
        UUID ownerId = entity.getOwnerId();
        if (ownerId == null) {
            return;
        }
        Player owner = entity.level().getPlayerByUUID(ownerId);
        if (owner == null) {
            return;
        }
        double ox = Mth.lerp(partialTick, owner.xo, owner.getX()) - Mth.lerp(partialTick, entity.xo, entity.getX());
        double oy = Mth.lerp(partialTick, owner.yo, owner.getY()) - Mth.lerp(partialTick, entity.yo, entity.getY());
        double oz = Mth.lerp(partialTick, owner.zo, owner.getZ()) - Mth.lerp(partialTick, entity.zo, entity.getZ());
        float bodyYaw = Mth.rotLerp(partialTick, owner.yBodyRotO, owner.yBodyRot);

        float alpha = 0.95F;
        Minecraft mc = Minecraft.getInstance();
        if (owner == mc.player && mc.options.getCameraType().isFirstPerson()) {
            alpha = 0.3F; // keep the view clear from the inside
        }

        poseStack.pushPose();
        poseStack.translate(ox, oy, oz);
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - bodyYaw));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0D, -1.501D, 0.0D);
        this.model.setupAnim(entity, 0.0F, 0.0F, entity.tickCount + partialTick, 0.0F, 0.0F);
        VertexConsumer consumer = buffer.getBuffer(RenderType.eyes(TEXTURE));
        this.model.renderToBuffer(poseStack, consumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY,
                1.0F, 1.0F, 1.0F, alpha);
        poseStack.popPose();
        super.render(entity, entityYaw, partialTick, poseStack, buffer, packedLight);
    }
}
