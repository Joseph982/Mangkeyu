package com.mangekyo.client.render;

import com.mangekyo.Mangekyo;
import com.mangekyo.item.MangekyoSharinganItem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;

import java.util.function.Predicate;

/**
 * Glowing red Mangekyo eyes painted exactly on the skin's eye pixels (the head UV of any 64x64 skin),
 * drawn full-bright so they glow in the dark.
 */
public class SharinganEyesLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation EYES =
            new ResourceLocation(Mangekyo.MODID, "textures/entity/sharingan_eyes.png");

    private final Predicate<? super T> shouldRender;

    public SharinganEyesLayer(RenderLayerParent<T, M> parent, Predicate<? super T> shouldRender) {
        super(parent);
        this.shouldRender = shouldRender;
    }

    public static boolean wearsEyes(LivingEntity entity) {
        return entity.getItemBySlot(EquipmentSlot.HEAD).getItem() instanceof MangekyoSharinganItem
                && !entity.isInvisible();
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if (!this.shouldRender.test(entity)) {
            return;
        }
        VertexConsumer consumer = buffer.getBuffer(RenderType.entityTranslucentEmissive(EYES));
        this.getParentModel().head.render(poseStack, consumer, LightTexture.FULL_BRIGHT,
                OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
