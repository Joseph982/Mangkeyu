package com.mangekyo.client;

import com.mangekyo.Mangekyo;
import com.mangekyo.client.model.SusanooModel;
import com.mangekyo.client.render.SharinganEyesLayer;
import com.mangekyo.client.render.ShadowCloneRenderer;
import com.mangekyo.client.render.SusanooRenderer;
import com.mangekyo.registry.ModEntities;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.entity.player.PlayerRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Mangekyo.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        for (KeyMapping mapping : ModKeys.KEYS.keySet()) {
            event.register(mapping);
        }
        for (KeyMapping mapping : ModKeys.LOCAL) {
            event.register(mapping);
        }
    }

    @SubscribeEvent
    public static void registerOverlays(RegisterGuiOverlaysEvent event) {
        event.registerAboveAll("mangekyo_wheel", WheelOverlay.OVERLAY);
    }

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(SusanooModel.LAYER, SusanooModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SUSANOO.get(), SusanooRenderer::new);
        event.registerEntityRenderer(ModEntities.CLONE.get(), ShadowCloneRenderer::new);
    }

    @SubscribeEvent
    public static void addLayers(EntityRenderersEvent.AddLayers event) {
        PlayerRenderer normal = event.getSkin("default");
        if (normal != null) {
            normal.addLayer(new SharinganEyesLayer<>(normal, SharinganEyesLayer::wearsEyes));
        }
        PlayerRenderer slim = event.getSkin("slim");
        if (slim != null) {
            slim.addLayer(new SharinganEyesLayer<>(slim, SharinganEyesLayer::wearsEyes));
        }
    }
}
