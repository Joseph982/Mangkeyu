package com.mangekyo.registry;

import com.mangekyo.Mangekyo;
import com.mangekyo.item.MangekyoSharinganItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Mangekyo.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Mangekyo.MODID);

    public static final RegistryObject<Item> MANGEKYO_SHARINGAN = ITEMS.register("mangekyo_sharingan",
            () -> new MangekyoSharinganItem(new Item.Properties().stacksTo(1).fireResistant().rarity(Rarity.EPIC)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.mangekyo"))
                    .icon(() -> new ItemStack(MANGEKYO_SHARINGAN.get()))
                    .displayItems((params, output) -> output.accept(MANGEKYO_SHARINGAN.get()))
                    .build());
}
