package com.mangekyo.registry;

import com.mangekyo.Mangekyo;
import com.mangekyo.entity.ShadowCloneEntity;
import com.mangekyo.entity.SusanooEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Mangekyo.MODID);

    public static final RegistryObject<EntityType<SusanooEntity>> SUSANOO = ENTITIES.register("susanoo",
            () -> EntityType.Builder.<SusanooEntity>of(SusanooEntity::new, MobCategory.MISC)
                    .sized(0.5F, 0.5F)
                    .noSave()
                    .noSummon()
                    .fireImmune()
                    .clientTrackingRange(16)
                    .updateInterval(2)
                    .build("susanoo"));

    public static final RegistryObject<EntityType<ShadowCloneEntity>> CLONE = ENTITIES.register("shadow_clone",
            () -> EntityType.Builder.<ShadowCloneEntity>of(ShadowCloneEntity::new, MobCategory.MISC)
                    .sized(0.6F, 1.8F)
                    .noSave()
                    .fireImmune()
                    .clientTrackingRange(10)
                    .build("shadow_clone"));

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(CLONE.get(), ShadowCloneEntity.createAttributes().build());
    }
}
