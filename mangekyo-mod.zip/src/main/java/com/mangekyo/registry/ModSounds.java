package com.mangekyo.registry;

import com.mangekyo.Mangekyo;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, Mangekyo.MODID);

    public static final RegistryObject<SoundEvent> SHARINGAN = reg("sharingan_activate");
    public static final RegistryObject<SoundEvent> SUSANOO = reg("susanoo_activate");
    public static final RegistryObject<SoundEvent> GENJUTSU = reg("genjutsu_cast");
    public static final RegistryObject<SoundEvent> GENJUTSU_AMBIENT = reg("genjutsu_ambient");
    public static final RegistryObject<SoundEvent> CLONE_VANISH = reg("clone_vanish");
    public static final RegistryObject<SoundEvent> TSUKUYOMI = reg("tsukuyomi");
    public static final RegistryObject<SoundEvent> AMATERASU = reg("amaterasu");
    public static final RegistryObject<SoundEvent> KAMUI = reg("kamui");
    public static final RegistryObject<SoundEvent> IZANAGI = reg("izanagi");
    public static final RegistryObject<SoundEvent> WAKE = reg("wake_up");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(Mangekyo.MODID, name)));
    }
}
