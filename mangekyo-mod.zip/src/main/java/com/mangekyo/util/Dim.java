package com.mangekyo.util;

import com.mangekyo.Mangekyo;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;

public final class Dim {
    public static final ResourceKey<Level> RED =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(Mangekyo.MODID, "tsukuyomi"));
    public static final ResourceKey<Level> DREAM =
            ResourceKey.create(Registries.DIMENSION, new ResourceLocation(Mangekyo.MODID, "dream_world"));

    private Dim() {
    }

    /** First free block above the terrain at x,z (loads/generates the chunk). */
    public static int surfaceY(ServerLevel level, int x, int z) {
        level.getChunk(x >> 4, z >> 4);
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
        return Math.max(y, level.getMinBuildHeight() + 2);
    }

    /** Uses the preferred Y when it is a valid standing spot, otherwise the surface. */
    public static double safeY(ServerLevel level, int x, double preferred, int z) {
        level.getChunk(x >> 4, z >> 4);
        int py = (int) Math.floor(preferred);
        if (py > level.getMinBuildHeight() + 1 && py < level.getMaxBuildHeight() - 3) {
            BlockPos feet = new BlockPos(x, py, z);
            BlockPos head = feet.above();
            BlockPos below = feet.below();
            boolean feetFree = level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                    && level.getFluidState(feet).isEmpty();
            boolean headFree = level.getBlockState(head).getCollisionShape(level, head).isEmpty()
                    && level.getFluidState(head).isEmpty();
            boolean solidBelow = !level.getBlockState(below).getCollisionShape(level, below).isEmpty();
            if (feetFree && headFree && solidBelow) {
                return py;
            }
        }
        return surfaceY(level, x, z);
    }
}
