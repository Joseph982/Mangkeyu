package com.mangekyo.util;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class Cooldowns {
    private static final Map<UUID, long[]> MAP = new HashMap<>();

    private Cooldowns() {
    }

    public static boolean tryUse(ServerPlayer player, int slot, int ticks, String name) {
        long now = player.level().getGameTime();
        long[] arr = MAP.computeIfAbsent(player.getUUID(), k -> new long[16]);
        if (arr[slot] > now) {
            long left = (arr[slot] - now + 19L) / 20L;
            player.displayClientMessage(Component.literal(name + " is recharging: " + left + "s"), true);
            return false;
        }
        arr[slot] = now + ticks;
        return true;
    }
}
