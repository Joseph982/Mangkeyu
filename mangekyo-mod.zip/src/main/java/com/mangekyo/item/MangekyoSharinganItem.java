package com.mangekyo.item;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

public class MangekyoSharinganItem extends ArmorItem {
    public MangekyoSharinganItem(Item.Properties properties) {
        super(MangekyoArmorMaterial.INSTANCE, ArmorItem.Type.HELMET, properties);
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("Press Z to awaken the eyes").withStyle(ChatFormatting.RED));
        tooltip.add(Component.literal("1 Susanoo  2 Tsukuyomi  3 Amaterasu").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("4 Kamui  5 Izanagi").withStyle(ChatFormatting.GRAY));
    }
}
