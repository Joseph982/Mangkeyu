package com.mangekyo.network;

import com.mangekyo.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server to client: which wheel the side-of-screen selector should show. */
public class WheelPacket {
    private final int mode;

    public WheelPacket(int mode) {
        this.mode = mode;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(this.mode);
    }

    public static WheelPacket decode(FriendlyByteBuf buf) {
        return new WheelPacket(buf.readVarInt());
    }

    public static void handle(WheelPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientState.setWheel(msg.mode)));
        context.setPacketHandled(true);
    }
}
