package com.mangekyo.network;

import com.mangekyo.ability.Abilities;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class AbilityPacket {
    private final int id;

    public AbilityPacket(int id) {
        this.id = id;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeVarInt(this.id);
    }

    public static AbilityPacket decode(FriendlyByteBuf buf) {
        return new AbilityPacket(buf.readVarInt());
    }

    public static void handle(AbilityPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> {
            ServerPlayer player = context.getSender();
            if (player != null) {
                Abilities.handle(player, msg.id);
            }
        });
        context.setPacketHandled(true);
    }
}
