package com.mangekyo.network;

import com.mangekyo.client.ClientState;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server to client: lock (or unlock) the player's movement and camera. */
public class FreezePacket {
    private final boolean frozen;
    private final float yaw;
    private final float pitch;

    public FreezePacket(boolean frozen, float yaw, float pitch) {
        this.frozen = frozen;
        this.yaw = yaw;
        this.pitch = pitch;
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeBoolean(this.frozen);
        buf.writeFloat(this.yaw);
        buf.writeFloat(this.pitch);
    }

    public static FreezePacket decode(FriendlyByteBuf buf) {
        return new FreezePacket(buf.readBoolean(), buf.readFloat(), buf.readFloat());
    }

    public static void handle(FreezePacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context context = ctx.get();
        context.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientState.set(msg.frozen, msg.yaw, msg.pitch)));
        context.setPacketHandled(true);
    }
}
