package com.mangekyo.network;

import com.mangekyo.Mangekyo;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNetwork {
    private static final String VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Mangekyo.MODID, "main"),
            () -> VERSION, VERSION::equals, VERSION::equals);

    private ModNetwork() {
    }

    public static void register() {
        int id = 0;
        CHANNEL.registerMessage(id++, AbilityPacket.class, AbilityPacket::encode, AbilityPacket::decode, AbilityPacket::handle);
        CHANNEL.registerMessage(id++, FreezePacket.class, FreezePacket::encode, FreezePacket::decode, FreezePacket::handle);
        CHANNEL.registerMessage(id++, WheelPacket.class, WheelPacket::encode, WheelPacket::decode, WheelPacket::handle);
    }
}
