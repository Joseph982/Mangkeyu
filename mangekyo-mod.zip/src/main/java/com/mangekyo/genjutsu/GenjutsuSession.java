package com.mangekyo.genjutsu;

import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class GenjutsuSession {
    public enum Stage {
        RED,
        DREAM
    }

    public static final int SPECTATE_NONE = 0;
    public static final int SPECTATE_EYES = 1;
    public static final int SPECTATE_FREE = 2;

    public final UUID caster;
    public final UUID target;
    public final boolean playerTarget;
    public final ResourceKey<Level> originDim;
    public final Vec3 originPos;
    public final float originYaw;
    public final float originPitch;

    public Stage stage = Stage.RED;
    public int age = 0;
    public UUID bodyId = null;
    public final List<UUID> mobs = new ArrayList<>();
    public final List<UUID> swords = new ArrayList<>();

    public boolean torture = false;
    public int tortureTicks = 0;
    public Vec3 frozenPos = Vec3.ZERO;
    public float frozenYaw = 0.0F;
    public float frozenPitch = 0.0F;

    public int spectate = SPECTATE_NONE;
    public ResourceKey<Level> retDim = null;
    public Vec3 retPos = Vec3.ZERO;
    public float retYaw = 0.0F;
    public float retPitch = 0.0F;
    public GameType retMode = GameType.SURVIVAL;

    public final Set<Long> forced = new HashSet<>();
    public ResourceKey<Level> forcedDim = null;

    public GenjutsuSession(UUID caster, UUID target, boolean playerTarget, ResourceKey<Level> originDim,
                           Vec3 originPos, float originYaw, float originPitch) {
        this.caster = caster;
        this.target = target;
        this.playerTarget = playerTarget;
        this.originDim = originDim;
        this.originPos = originPos;
        this.originYaw = originYaw;
        this.originPitch = originPitch;
    }
}
