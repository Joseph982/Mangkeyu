package com.mangekyo.genjutsu;

import com.mangekyo.ability.Abilities;
import com.mangekyo.ability.Wheel;
import com.mangekyo.entity.ShadowCloneEntity;
import com.mangekyo.network.FreezePacket;
import com.mangekyo.network.ModNetwork;
import com.mangekyo.network.WheelPacket;
import com.mangekyo.registry.ModEntities;
import com.mangekyo.registry.ModSounds;
import com.mangekyo.util.Cooldowns;
import com.mangekyo.util.Dim;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Runs the Tsukuyomi genjutsu: one session per caster. The victim (player OR any mob) is moved into the red-sky
 * dimension while a frozen copy of it stays behind in the original world.
 */
public final class GenjutsuManager {
    private static final Map<UUID, GenjutsuSession> BY_CASTER = new HashMap<>();
    private static final Map<UUID, GenjutsuSession> BY_TARGET = new HashMap<>();
    private static final UUID SLOW_ID = UUID.fromString("5f0b2b6e-7a1c-4a43-9a43-1f5c7a1d9e01");
    private static final int TORTURE_TICKS = 2400; // 2 minutes

    private GenjutsuManager() {
    }

    // ------------------------------------------------------------------ queries

    public static boolean isTarget(UUID id) {
        return BY_TARGET.containsKey(id);
    }

    public static boolean isFrozen(UUID id) {
        GenjutsuSession s = BY_TARGET.get(id);
        return s != null && s.torture;
    }

    public static boolean isSessionMob(UUID id) {
        for (GenjutsuSession s : BY_CASTER.values()) {
            if (s.mobs.contains(id)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isSessionBody(UUID id) {
        for (GenjutsuSession s : BY_CASTER.values()) {
            if (id.equals(s.bodyId)) {
                return true;
            }
        }
        return false;
    }

    public static void endFor(ServerPlayer caster) {
        GenjutsuSession s = BY_CASTER.get(caster.getUUID());
        if (s != null) {
            end(s, true);
        }
    }

    /** Wake everybody up (server stopping / world closing). */
    public static void endAll() {
        for (GenjutsuSession s : new ArrayList<>(BY_CASTER.values())) {
            end(s, true);
        }
    }

    /** Forced chunks survive restarts, so clear any leftovers in our two dimensions on startup. */
    public static void clearStaleForcedChunks(MinecraftServer server) {
        for (ResourceKey<net.minecraft.world.level.Level> key : java.util.List.of(Dim.RED, Dim.DREAM)) {
            ServerLevel level = server.getLevel(key);
            if (level == null) {
                continue;
            }
            for (long pos : new ArrayList<>(level.getForcedChunks())) {
                level.setChunkForced(ChunkPos.getX(pos), ChunkPos.getZ(pos), false);
            }
        }
    }

    private static Entity find(MinecraftServer server, UUID id) {
        if (id == null) {
            return null;
        }
        for (ServerLevel level : server.getAllLevels()) {
            Entity e = level.getEntity(id);
            if (e != null) {
                return e;
            }
        }
        return null;
    }

    private static void msg(ServerPlayer p, String text) {
        p.displayClientMessage(Component.literal(text), true);
    }

    /** Damage that can never kill: a genjutsu hurts but does not finish anyone. */
    public static void mentalDamage(LivingEntity victim, Entity source, float damage, boolean magic) {
        float amount = Math.min(damage, victim.getHealth() - 1.0F);
        if (amount <= 0.0F) {
            return;
        }
        DamageSource ds;
        if (magic) {
            ds = victim.level().damageSources().indirectMagic(source, source);
        } else if (source instanceof LivingEntity living) {
            ds = victim.level().damageSources().mobAttack(living);
        } else {
            ds = victim.level().damageSources().generic();
        }
        victim.invulnerableTime = 0;
        victim.hurt(ds, amount);
    }

    // ------------------------------------------------------------------ moving entities between worlds

    /**
     * Moves any entity to another dimension. Players keep their object; other entities are recreated in the
     * destination with all their data (same UUID), exactly like a portal does. Returns the live entity.
     */
    private static Entity moveEntity(Entity entity, ServerLevel dest, double x, double y, double z,
                                     float yaw, float pitch) {
        if (entity instanceof ServerPlayer player) {
            player.teleportTo(dest, x, y, z, yaw, pitch);
            return player;
        }
        if (entity.level() == dest) {
            entity.moveTo(x, y, z, yaw, pitch);
            return entity;
        }
        Entity copy = entity.getType().create(dest);
        if (copy == null) {
            return entity;
        }
        copy.restoreFrom(entity);
        copy.moveTo(x, y, z, yaw, pitch);
        copy.setDeltaMovement(Vec3.ZERO);
        entity.discard();
        dest.addFreshEntity(copy);
        return copy;
    }

    /** The copy of the victim that stays behind: a skinned frozen clone for players, a frozen duplicate for mobs. */
    private static void spawnBody(GenjutsuSession s, ServerPlayer caster, LivingEntity target, ServerLevel level) {
        if (target instanceof ServerPlayer victim) {
            ShadowCloneEntity body = ModEntities.CLONE.get().create(level);
            if (body == null) {
                return;
            }
            body.setSkinOwner(victim.getUUID());
            body.setCasterId(caster.getUUID());
            body.moveTo(victim.getX(), victim.getY(), victim.getZ(), victim.getYRot(), 0.0F);
            for (EquipmentSlot slot : EquipmentSlot.values()) {
                body.setItemSlot(slot, victim.getItemBySlot(slot).copy());
            }
            body.setMode(ShadowCloneEntity.MODE_BODY);
            body.setYHeadRot(victim.getYHeadRot());
            body.setYBodyRot(victim.yBodyRot);
            s.bodyId = body.getUUID();
            level.addFreshEntity(body);
            return;
        }
        Entity decoy = target.getType().create(level);
        if (decoy == null) {
            return;
        }
        decoy.restoreFrom(target);
        decoy.setUUID(UUID.randomUUID());
        decoy.getPersistentData().remove("mk_entranced");
        decoy.getPersistentData().putBoolean("mk_decoy", true);
        decoy.setInvulnerable(true);
        decoy.setSilent(true);
        decoy.moveTo(target.getX(), target.getY(), target.getZ(), target.getYRot(), target.getXRot());
        if (decoy instanceof Mob mob) {
            mob.setNoAi(true);
            mob.setPersistenceRequired();
        }
        s.bodyId = decoy.getUUID();
        level.addFreshEntity(decoy);
    }

    // ------------------------------------------------------------------ cast

    public static void cast(ServerPlayer caster) {
        if (BY_CASTER.containsKey(caster.getUUID())) {
            msg(caster, "A genjutsu is already active. Press the Wake Up key to end it.");
            return;
        }
        LivingEntity target = Abilities.pickTarget(caster, 32.0D);
        if (target == null) {
            msg(caster, "Look straight at a mob or player to cast the genjutsu.");
            return;
        }
        if (target instanceof ShadowCloneEntity || BY_TARGET.containsKey(target.getUUID())
                || target.getPersistentData().getBoolean("mk_decoy")) {
            msg(caster, "That target cannot be caught right now.");
            return;
        }
        target.stopRiding();
        target.ejectPassengers();
        if (!target.canChangeDimensions()) {
            msg(caster, "That being cannot be pulled into a genjutsu.");
            return;
        }
        if (!Cooldowns.tryUse(caster, 2, 100, "Tsukuyomi")) {
            return;
        }
        start(caster, target);
    }

    private static void start(ServerPlayer caster, LivingEntity target) {
        MinecraftServer server = caster.getServer();
        if (server == null) {
            return;
        }
        ServerLevel red = server.getLevel(Dim.RED);
        if (red == null) {
            msg(caster, "The genjutsu dimension did not load. Is the mod data pack active?");
            return;
        }
        ServerLevel originLevel = (ServerLevel) target.level();
        GenjutsuSession s = new GenjutsuSession(caster.getUUID(), target.getUUID(), target instanceof ServerPlayer,
                originLevel.dimension(), target.position(), target.getYRot(), target.getXRot());
        // register first so the join handlers recognise the entities we are about to create
        BY_CASTER.put(s.caster, s);
        BY_TARGET.put(s.target, s);

        if (target instanceof ServerPlayer victim) {
            saveOrigin(victim, s);
        } else {
            target.getPersistentData().putBoolean("mk_entranced", true);
        }
        spawnBody(s, caster, target, originLevel);

        int ix = Mth.floor(target.getX());
        int iz = Mth.floor(target.getZ());
        double y = Dim.surfaceY(red, ix, iz);
        Entity moved = moveEntity(target, red, target.getX(), y, target.getZ(), target.getYRot(), target.getXRot());
        if (moved.level() != red) {
            msg(caster, "The genjutsu failed to take hold.");
            end(s, false);
            return;
        }
        applySlow(moved);
        updateForced(server, s, moved);

        if (moved instanceof ServerPlayer vp) {
            vp.playNotifySound(ModSounds.GENJUTSU.get(), SoundSource.MASTER, 1.0F, 1.0F);
        }
        playAt(originLevel, caster.getX(), caster.getY(), caster.getZ(), ModSounds.GENJUTSU.get(), 1.2F, 1.0F);
        playAt(red, moved.getX(), moved.getY(), moved.getZ(), ModSounds.GENJUTSU.get(), 1.2F, 1.0F);
        msg(caster, moved.getName().getString() + " is trapped. A copy of them stands here, the real one is in the red world.");
        sendWheel(caster, Wheel.MODE_RED);
        ring(s, 8, 6.0D);
    }

    private static void playAt(ServerLevel level, double x, double y, double z, SoundEvent sound, float vol, float pitch) {
        level.playSound(null, x, y, z, sound, SoundSource.PLAYERS, vol, pitch);
    }

    // ------------------------------------------------------------------ commands inside the genjutsu

    public static void command(ServerPlayer caster, int id) {
        GenjutsuSession s = BY_CASTER.get(caster.getUUID());
        if (s == null) {
            msg(caster, "No genjutsu active. Cast Tsukuyomi on a target first.");
            return;
        }
        switch (id) {
            case Abilities.G_WATCH:
                spectate(s, caster, GenjutsuSession.SPECTATE_EYES);
                break;
            case Abilities.G_ENTER:
                spectate(s, caster, GenjutsuSession.SPECTATE_FREE);
                break;
            case Abilities.G_CLONES:
                if (s.torture) {
                    msg(caster, "The Tsukuyomi is in progress.");
                } else {
                    ring(s, 8, 6.0D);
                }
                break;
            case Abilities.G_ATTACK:
                setCloneMode(s, ShadowCloneEntity.MODE_ATTACK);
                break;
            case Abilities.G_FADE:
                setCloneMode(s, ShadowCloneEntity.MODE_FADE);
                break;
            case Abilities.G_SWORDS:
                toggleTorture(s, caster);
                break;
            case Abilities.G_DREAM:
                toggleDream(s, caster);
                break;
            case Abilities.G_NIGHTMARE:
                nightmare(s, caster);
                break;
            case Abilities.G_WATCHER:
                watcher(s, caster);
                break;
            case Abilities.G_WAKE:
                msg(caster, "You release the genjutsu.");
                end(s, true);
                break;
            default:
                break;
        }
    }

    private static ShadowCloneEntity createClone(ServerLevel level, GenjutsuSession s, double x, double y, double z) {
        ShadowCloneEntity clone = ModEntities.CLONE.get().create(level);
        if (clone == null) {
            return null;
        }
        clone.setSkinOwner(s.caster);
        clone.setCasterId(s.caster);
        clone.setVictimId(s.target);
        clone.moveTo(x, y, z, 0.0F, 0.0F);
        clone.setMode(ShadowCloneEntity.MODE_STARE);
        level.addFreshEntity(clone);
        s.mobs.add(clone.getUUID());
        return clone;
    }

    /** Evenly spaced ring of clones, all staring at the victim. Exact positions, never random. */
    private static void ring(GenjutsuSession s, int count, double radius) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        Entity victim = find(server, s.target);
        if (victim == null) {
            return;
        }
        ServerLevel level = (ServerLevel) victim.level();
        clearMobs(s);
        for (int i = 0; i < count; i++) {
            double angle = (Math.PI * 2.0D / count) * i;
            double x = victim.getX() + Math.cos(angle) * radius;
            double z = victim.getZ() + Math.sin(angle) * radius;
            double y = Dim.surfaceY(level, Mth.floor(x), Mth.floor(z));
            createClone(level, s, x, y, z);
        }
    }

    private static void clearMobs(GenjutsuSession s) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        for (UUID id : new ArrayList<>(s.mobs)) {
            Entity e = find(server, id);
            if (e instanceof ShadowCloneEntity clone) {
                clone.vanish(false);
            } else if (e != null) {
                e.discard();
            }
        }
        s.mobs.clear();
        s.swords.clear();
    }

    private static void setCloneMode(GenjutsuSession s, int mode) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        for (UUID id : new ArrayList<>(s.mobs)) {
            Entity e = find(server, id);
            if (e instanceof ShadowCloneEntity clone && clone.getMode() == ShadowCloneEntity.MODE_STARE) {
                clone.setMode(mode);
            }
        }
    }

    private static void nightmare(GenjutsuSession s, ServerPlayer caster) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        Entity victim = find(server, s.target);
        if (!(victim instanceof LivingEntity living)) {
            return;
        }
        ServerLevel level = (ServerLevel) victim.level();
        EntityType<?>[] types = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
                EntityType.ENDERMAN, EntityType.WITCH};
        EntityType<?> type = types[level.random.nextInt(types.length)];
        Entity created = type.create(level);
        if (!(created instanceof Mob mob)) {
            return;
        }
        double angle = level.random.nextDouble() * Math.PI * 2.0D;
        double x = victim.getX() + Math.cos(angle) * 7.0D;
        double z = victim.getZ() + Math.sin(angle) * 7.0D;
        double y = Dim.surfaceY(level, Mth.floor(x), Mth.floor(z));
        mob.moveTo(x, y, z, level.random.nextFloat() * 360.0F, 0.0F);
        mob.getPersistentData().putBoolean("mk_nightmare", true);
        mob.setPersistenceRequired();
        s.mobs.add(mob.getUUID());
        mob.finalizeSpawn(level, level.getCurrentDifficultyAt(mob.blockPosition()), MobSpawnType.COMMAND, null, null);
        mob.setTarget(living);
        level.addFreshEntity(mob);
        msg(caster, "A nightmare crawls out of the dark.");
    }

    private static void sendWheel(ServerPlayer player, int mode) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new WheelPacket(mode));
    }

    /** Dream world only: a clone of the caster appears far away, staring. 2 seconds after it is seen it dissolves. */
    private static void watcher(GenjutsuSession s, ServerPlayer caster) {
        if (s.stage != GenjutsuSession.Stage.DREAM) {
            msg(caster, "The Watcher only appears in the dream world.");
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        Entity victim = find(server, s.target);
        if (victim == null) {
            return;
        }
        ServerLevel level = (ServerLevel) victim.level();
        int active = 0;
        for (UUID id : new ArrayList<>(s.mobs)) {
            Entity e = find(server, id);
            if (e instanceof ShadowCloneEntity clone && clone.getMode() == ShadowCloneEntity.MODE_WATCHER) {
                active++;
            }
        }
        if (active >= 3) {
            msg(caster, "Three watchers already stand in the distance.");
            return;
        }
        double bx = victim.getX();
        double by = victim.getY();
        double bz = victim.getZ();
        boolean visible = false;
        for (int attempt = 0; attempt < 10 && !visible; attempt++) {
            double distance = 30.0D - attempt * 2.0D;
            double offset = level.random.nextDouble() * 70.0D - 35.0D; // somewhere in front of where they look
            double a = Math.toRadians(victim.getYRot() + offset);
            double x = victim.getX() - Math.sin(a) * distance;
            double z = victim.getZ() + Math.cos(a) * distance;
            double y = Dim.surfaceY(level, Mth.floor(x), Mth.floor(z));
            bx = x;
            by = y;
            bz = z;
            Vec3 from = victim.getEyePosition();
            Vec3 to = new Vec3(x, y + 1.6D, z);
            visible = level.clip(new ClipContext(from, to, ClipContext.Block.COLLIDER,
                    ClipContext.Fluid.NONE, victim)).getType() == HitResult.Type.MISS;
        }
        ShadowCloneEntity clone = createClone(level, s, bx, by, bz);
        if (clone != null) {
            clone.setMode(ShadowCloneEntity.MODE_WATCHER);
            msg(caster, "A watcher stands in the distance.");
        }
    }

    // ------------------------------------------------------------------ being inside the genjutsu as an invisible spectator

    /**
     * SPECTATE_EYES: see exactly through the victim's eyes.
     * SPECTATE_FREE: stand in their world as an invisible, free-flying presence (they cannot see you).
     * Pressing the same key again takes you back to where you were. Both modes keep every ability key working.
     */
    private static void spectate(GenjutsuSession s, ServerPlayer caster, int wanted) {
        if (s.spectate == wanted) {
            stopSpectating(s, caster);
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        Entity victim = find(server, s.target);
        if (victim == null) {
            return;
        }
        if (s.spectate == GenjutsuSession.SPECTATE_NONE) {
            s.retDim = caster.level().dimension();
            s.retPos = caster.position();
            s.retYaw = caster.getYRot();
            s.retPitch = caster.getXRot();
            s.retMode = caster.gameMode.getGameModeForPlayer();
            saveWatch(caster, s);
            caster.setGameMode(GameType.SPECTATOR);
        }
        s.spectate = wanted;
        applySpectate(s, caster, victim);
        if (wanted == GenjutsuSession.SPECTATE_EYES) {
            msg(caster, "You see through their eyes. They cannot see you.");
        } else {
            msg(caster, "You walk invisible in their world. Press again to return.");
        }
    }

    private static void applySpectate(GenjutsuSession s, ServerPlayer caster, Entity victim) {
        if (s.spectate == GenjutsuSession.SPECTATE_EYES) {
            caster.setCamera(null);
            caster.setCamera(victim);
        } else if (s.spectate == GenjutsuSession.SPECTATE_FREE) {
            caster.setCamera(null);
            double yaw = Math.toRadians(victim.getYRot());
            double x = victim.getX() + Math.sin(yaw) * 4.0D;
            double z = victim.getZ() - Math.cos(yaw) * 4.0D;
            caster.teleportTo((ServerLevel) victim.level(), x, victim.getY() + 2.0D, z, victim.getYRot(), 15.0F);
        }
    }

    private static void stopSpectating(GenjutsuSession s, ServerPlayer caster) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        caster.setCamera(null);
        caster.setGameMode(s.retMode);
        ServerLevel back = (server == null || s.retDim == null) ? null : server.getLevel(s.retDim);
        if (back != null) {
            caster.teleportTo(back, s.retPos.x, s.retPos.y, s.retPos.z, s.retYaw, s.retPitch);
        }
        s.spectate = GenjutsuSession.SPECTATE_NONE;
        caster.getPersistentData().remove("mk_watch");
    }

    private static void respectate(GenjutsuSession s, ServerPlayer caster, Entity victim) {
        if (s.spectate != GenjutsuSession.SPECTATE_NONE) {
            applySpectate(s, caster, victim);
        }
    }

    // ------------------------------------------------------------------ Tsukuyomi: paralysis + sword clones

    private static void toggleTorture(GenjutsuSession s, ServerPlayer caster) {
        if (s.torture) {
            endTorture(s);
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        Entity victim = find(server, s.target);
        if (victim == null) {
            return;
        }
        ServerLevel level = (ServerLevel) victim.level();
        clearMobs(s);

        float yaw = victim.getYRot();
        float pitch = 8.0F;
        double[] offsets = {-42.0D, -14.0D, 14.0D, 42.0D};
        for (double offset : offsets) {
            double a = Math.toRadians(yaw + offset);
            double x = victim.getX() - Math.sin(a) * 3.4D;
            double z = victim.getZ() + Math.cos(a) * 3.4D;
            double y = Dim.safeY(level, Mth.floor(x), victim.getY(), Mth.floor(z));
            ShadowCloneEntity clone = createClone(level, s, x, y, z);
            if (clone != null) {
                clone.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.NETHERITE_SWORD));
                clone.setDropChance(EquipmentSlot.MAINHAND, 0.0F);
                clone.setMode(ShadowCloneEntity.MODE_SWORD);
                s.swords.add(clone.getUUID());
            }
        }
        s.torture = true;
        s.tortureTicks = 0;
        s.frozenPos = victim.position();
        s.frozenYaw = yaw;
        s.frozenPitch = pitch;

        if (victim instanceof ServerPlayer vp) {
            vp.connection.teleport(vp.getX(), vp.getY(), vp.getZ(), yaw, pitch);
            send(vp, true, yaw, pitch);
            vp.playNotifySound(ModSounds.TSUKUYOMI.get(), SoundSource.MASTER, 1.2F, 1.0F);
        } else if (victim instanceof Mob mob) {
            mob.setNoAi(true);
        }
        playAt(level, victim.getX(), victim.getY(), victim.getZ(), ModSounds.TSUKUYOMI.get(), 1.5F, 1.0F);
        msg(caster, "Tsukuyomi: 2 minutes in the moonlit world.");
    }

    private static void endTorture(GenjutsuSession s) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        for (UUID id : new ArrayList<>(s.swords)) {
            Entity e = find(server, id);
            if (e instanceof ShadowCloneEntity clone) {
                clone.vanish(false);
            }
            s.mobs.remove(id);
        }
        s.swords.clear();
        s.torture = false;
        s.tortureTicks = 0;
        Entity victim = find(server, s.target);
        if (victim instanceof ServerPlayer vp) {
            send(vp, false, 0.0F, 0.0F);
        } else if (victim instanceof Mob mob) {
            mob.setNoAi(false);
        }
        if (victim != null && s.stage == GenjutsuSession.Stage.RED) {
            ring(s, 8, 6.0D);
        }
    }

    private static void tickTorture(GenjutsuSession s, Entity victim) {
        s.tortureTicks++;
        if (victim instanceof ServerPlayer vp) {
            if (vp.position().distanceToSqr(s.frozenPos) > 0.25D) {
                vp.connection.teleport(s.frozenPos.x, s.frozenPos.y, s.frozenPos.z, s.frozenYaw, s.frozenPitch);
            }
        }
        // one clone at a time starts a lunge + slash every second
        if (s.tortureTicks % 20 == 0 && !s.swords.isEmpty()) {
            int index = (s.tortureTicks / 20) % s.swords.size();
            Entity e = find(ServerLifecycleHooks.getCurrentServer(), s.swords.get(index));
            if (e instanceof ShadowCloneEntity clone) {
                clone.startSlash();
            }
        }
        if (s.tortureTicks >= TORTURE_TICKS) {
            endTorture(s);
        }
    }

    // ------------------------------------------------------------------ fake overworld

    private static void toggleDream(GenjutsuSession s, ServerPlayer caster) {
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        Entity victim = find(server, s.target);
        if (victim == null) {
            return;
        }
        if (s.torture) {
            endTorture(s);
            victim = find(server, s.target);
            if (victim == null) {
                return;
            }
        }
        clearMobs(s);
        Entity moved;
        if (s.stage == GenjutsuSession.Stage.RED) {
            ServerLevel dream = server.getLevel(Dim.DREAM);
            if (dream == null) {
                msg(caster, "The dream dimension did not load.");
                return;
            }
            double x = s.originPos.x;
            double z = s.originPos.z;
            double y = Dim.safeY(dream, Mth.floor(x), s.originPos.y, Mth.floor(z));
            moved = moveEntity(victim, dream, x, y, z, victim.getYRot(), victim.getXRot());
            removeSlow(moved);
            s.stage = GenjutsuSession.Stage.DREAM;
            msg(caster, "They believe they are home. Press again to drop them back into the red world.");
            sendWheel(caster, Wheel.MODE_DREAM);
        } else {
            ServerLevel red = server.getLevel(Dim.RED);
            if (red == null) {
                return;
            }
            double y = Dim.surfaceY(red, Mth.floor(victim.getX()), Mth.floor(victim.getZ()));
            moved = moveEntity(victim, red, victim.getX(), y, victim.getZ(), victim.getYRot(), victim.getXRot());
            applySlow(moved);
            s.stage = GenjutsuSession.Stage.RED;
            sendWheel(caster, Wheel.MODE_RED);
            if (moved instanceof ServerPlayer vp) {
                vp.playNotifySound(ModSounds.GENJUTSU.get(), SoundSource.MASTER, 1.0F, 0.8F);
            }
            updateForced(server, s, moved);
            ring(s, 8, 6.0D);
        }
        updateForced(server, s, moved);
        respectate(s, caster, moved);
    }

    // ------------------------------------------------------------------ keep the victim's chunks alive

    private static void updateForced(MinecraftServer server, GenjutsuSession s, Entity victim) {
        if (!(victim.level() instanceof ServerLevel level)) {
            return;
        }
        ResourceKey<net.minecraft.world.level.Level> dim = level.dimension();
        if (!dim.equals(Dim.RED) && !dim.equals(Dim.DREAM)) {
            releaseForced(server, s);
            return;
        }
        if (s.forcedDim != null && !s.forcedDim.equals(dim)) {
            releaseForced(server, s);
        }
        int cx = Mth.floor(victim.getX()) >> 4;
        int cz = Mth.floor(victim.getZ()) >> 4;
        Set<Long> wanted = new HashSet<>();
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                wanted.add(ChunkPos.asLong(cx + dx, cz + dz));
            }
        }
        for (Long pos : new ArrayList<>(s.forced)) {
            if (!wanted.contains(pos)) {
                level.setChunkForced(ChunkPos.getX(pos), ChunkPos.getZ(pos), false);
                s.forced.remove(pos);
            }
        }
        for (Long pos : wanted) {
            if (s.forced.add(pos)) {
                level.setChunkForced(ChunkPos.getX(pos), ChunkPos.getZ(pos), true);
            }
        }
        s.forcedDim = dim;
    }

    private static void releaseForced(MinecraftServer server, GenjutsuSession s) {
        if (s.forcedDim == null) {
            return;
        }
        ServerLevel level = server.getLevel(s.forcedDim);
        if (level != null) {
            for (Long pos : s.forced) {
                level.setChunkForced(ChunkPos.getX(pos), ChunkPos.getZ(pos), false);
            }
        }
        s.forced.clear();
        s.forcedDim = null;
    }

    // ------------------------------------------------------------------ ticking

    public static void tick() {
        if (BY_CASTER.isEmpty()) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }
        for (GenjutsuSession s : new ArrayList<>(BY_CASTER.values())) {
            ServerPlayer caster = server.getPlayerList().getPlayer(s.caster);
            Entity victim = find(server, s.target);
            if (caster == null || !caster.isAlive() || !Abilities.wearing(caster)
                    || victim == null || !victim.isAlive()) {
                end(s, true);
                continue;
            }
            s.age++;
            if (s.age % 20 == 0) {
                updateForced(server, s, victim);
            }
            s.mobs.removeIf(id -> find(server, id) == null);
            if (s.torture) {
                tickTorture(s, victim);
            }
            if (s.playerTarget && victim instanceof ServerPlayer vp && s.age % 160 == 0) {
                vp.playNotifySound(ModSounds.GENJUTSU_AMBIENT.get(), SoundSource.AMBIENT, 0.8F, 1.0F);
            }
        }
    }

    // ------------------------------------------------------------------ ending

    public static void end(GenjutsuSession s, boolean wake) {
        BY_CASTER.remove(s.caster);
        BY_TARGET.remove(s.target);
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }
        ServerPlayer caster = server.getPlayerList().getPlayer(s.caster);
        if (caster != null && s.spectate != GenjutsuSession.SPECTATE_NONE) {
            stopSpectating(s, caster);
        }
        clearMobs(s);
        // the copy that stayed behind goes first, so the real one can step back into its place
        if (s.bodyId != null) {
            Entity body = find(server, s.bodyId);
            if (body != null) {
                body.discard();
            }
        }
        Entity victim = find(server, s.target);
        if (victim != null) {
            removeSlow(victim);
            if (victim instanceof ServerPlayer vp) {
                send(vp, false, 0.0F, 0.0F);
                if (wake) {
                    returnPlayer(server, vp, s);
                }
            } else if (wake) {
                returnMob(server, victim, s);
            }
        }
        releaseForced(server, s);
        if (caster != null) {
            sendWheel(caster, Wheel.MODE_ABILITIES);
            if (wake) {
                msg(caster, "The genjutsu is released.");
            }
        }
    }

    private static void returnPlayer(MinecraftServer server, ServerPlayer victim, GenjutsuSession s) {
        ServerLevel origin = server.getLevel(s.originDim);
        if (origin != null) {
            victim.teleportTo(origin, s.originPos.x, s.originPos.y, s.originPos.z, s.originYaw, s.originPitch);
        }
        victim.getPersistentData().remove("mk_origin");
        victim.playNotifySound(ModSounds.WAKE.get(), SoundSource.MASTER, 1.2F, 1.0F);
        boolean wasDream = s.stage == GenjutsuSession.Stage.DREAM;
        victim.connection.send(new ClientboundSetTitlesAnimationPacket(10, 70, 30));
        victim.connection.send(new ClientboundSetTitleTextPacket(
                Component.literal(wasDream ? "It was a genjutsu." : "You are awake.")));
        victim.connection.send(new ClientboundSetSubtitleTextPacket(
                Component.literal(wasDream ? "None of it was real." : "The red sky is gone.")));
    }

    private static void returnMob(MinecraftServer server, Entity victim, GenjutsuSession s) {
        ServerLevel origin = server.getLevel(s.originDim);
        Entity back = victim;
        if (origin != null) {
            back = moveEntity(victim, origin, s.originPos.x, s.originPos.y, s.originPos.z, s.originYaw, s.originPitch);
        }
        back.getPersistentData().remove("mk_entranced");
        if (back instanceof Mob mob) {
            mob.setNoAi(false);
        }
        back.level().playSound(null, back.getX(), back.getY(), back.getZ(), ModSounds.WAKE.get(),
                SoundSource.HOSTILE, 1.0F, 1.0F);
    }

    // ------------------------------------------------------------------ login / logout safety

    public static void onLogout(ServerPlayer player) {
        GenjutsuSession asCaster = BY_CASTER.get(player.getUUID());
        if (asCaster != null) {
            end(asCaster, true);
        }
        GenjutsuSession asTarget = BY_TARGET.get(player.getUUID());
        if (asTarget != null) {
            end(asTarget, false); // origin stays saved on the player, restored at next login
        }
    }

    public static void onLogin(ServerPlayer player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        CompoundTag data = player.getPersistentData();
        if (data.contains("mk_origin") && !BY_TARGET.containsKey(player.getUUID())) {
            CompoundTag t = data.getCompound("mk_origin");
            ServerLevel level = server.getLevel(ResourceKey.create(Registries.DIMENSION,
                    new ResourceLocation(t.getString("dim"))));
            if (level != null) {
                player.teleportTo(level, t.getDouble("x"), t.getDouble("y"), t.getDouble("z"),
                        t.getFloat("yaw"), t.getFloat("pitch"));
            }
            data.remove("mk_origin");
            send(player, false, 0.0F, 0.0F);
        }
        if (data.contains("mk_watch") && !BY_CASTER.containsKey(player.getUUID())) {
            CompoundTag t = data.getCompound("mk_watch");
            player.setCamera(null);
            player.setGameMode(GameType.byId(t.getInt("mode")));
            ServerLevel level = server.getLevel(ResourceKey.create(Registries.DIMENSION,
                    new ResourceLocation(t.getString("dim"))));
            if (level != null) {
                player.teleportTo(level, t.getDouble("x"), t.getDouble("y"), t.getDouble("z"),
                        t.getFloat("yaw"), t.getFloat("pitch"));
            }
            data.remove("mk_watch");
        }
    }

    private static void saveOrigin(ServerPlayer victim, GenjutsuSession s) {
        CompoundTag t = new CompoundTag();
        t.putString("dim", s.originDim.location().toString());
        t.putDouble("x", s.originPos.x);
        t.putDouble("y", s.originPos.y);
        t.putDouble("z", s.originPos.z);
        t.putFloat("yaw", s.originYaw);
        t.putFloat("pitch", s.originPitch);
        victim.getPersistentData().put("mk_origin", t);
    }

    private static void saveWatch(ServerPlayer caster, GenjutsuSession s) {
        CompoundTag t = new CompoundTag();
        t.putString("dim", s.retDim.location().toString());
        t.putDouble("x", s.retPos.x);
        t.putDouble("y", s.retPos.y);
        t.putDouble("z", s.retPos.z);
        t.putFloat("yaw", s.retYaw);
        t.putFloat("pitch", s.retPitch);
        t.putInt("mode", s.retMode.getId());
        caster.getPersistentData().put("mk_watch", t);
    }

    // ------------------------------------------------------------------ helpers

    private static void send(ServerPlayer player, boolean frozen, float yaw, float pitch) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new FreezePacket(frozen, yaw, pitch));
    }

    private static void applySlow(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return;
        }
        AttributeInstance inst = living.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst == null) {
            return;
        }
        inst.removeModifier(SLOW_ID);
        inst.addTransientModifier(new AttributeModifier(SLOW_ID, "mangekyo_genjutsu_slow", -0.4D,
                AttributeModifier.Operation.MULTIPLY_TOTAL));
    }

    private static void removeSlow(Entity entity) {
        if (!(entity instanceof LivingEntity living)) {
            return;
        }
        AttributeInstance inst = living.getAttribute(Attributes.MOVEMENT_SPEED);
        if (inst != null) {
            inst.removeModifier(SLOW_ID);
        }
    }
}
