package com.mangekyo.event;

import com.mangekyo.Mangekyo;
import com.mangekyo.ability.Abilities;
import com.mangekyo.genjutsu.GenjutsuManager;
import com.mangekyo.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingExperienceDropEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = Mangekyo.MODID)
public class ServerEvents {

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        GenjutsuManager.tick();
        Abilities.tickBurning();
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.side != LogicalSide.SERVER) {
            return;
        }
        if (event.player instanceof ServerPlayer player) {
            Abilities.playerTick(player);
        }
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onHurt(LivingHurtEvent event) {
        LivingEntity victim = event.getEntity();
        float amount = event.getAmount();

        // Susanoo soaks up most damage
        if (victim instanceof ServerPlayer sp && Abilities.hasSusanoo(sp.getUUID())) {
            amount *= 0.2F;
        }
        // a genjutsu hurts but never kills
        if (GenjutsuManager.isTarget(victim.getUUID()) && amount >= victim.getHealth()) {
            amount = Math.max(0.0F, victim.getHealth() - 1.0F);
        }
        // Susanoo hits hard
        Entity attacker = event.getSource().getEntity();
        if (attacker instanceof ServerPlayer atk && Abilities.hasSusanoo(atk.getUUID())
                && event.getSource().getDirectEntity() == atk) {
            amount += 8.0F;
            Abilities.susanooSwing(atk);
            double dx = victim.getX() - atk.getX();
            double dz = victim.getZ() - atk.getZ();
            victim.knockback(1.2D, -dx, -dz);
        }
        event.setAmount(amount);
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp && Abilities.consumeIzanagi(sp)) {
            event.setCanceled(true);
            sp.setHealth(sp.getMaxHealth());
            sp.removeAllEffects();
            sp.clearFire();
            sp.fallDistance = 0.0F;
            ServerLevel level = (ServerLevel) sp.level();
            level.sendParticles(ParticleTypes.END_ROD, sp.getX(), sp.getY() + 1.0D, sp.getZ(),
                    60, 0.5D, 1.0D, 0.5D, 0.15D);
            level.playSound(null, sp.getX(), sp.getY(), sp.getZ(), ModSounds.IZANAGI.get(),
                    SoundSource.PLAYERS, 1.5F, 0.8F);
            sp.displayClientMessage(Component.literal("Izanagi rewrote your death."), true);
        }
    }

    @SubscribeEvent
    public static void onAttack(AttackEntityEvent event) {
        if (GenjutsuManager.isFrozen(event.getEntity().getUUID())) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onDrops(LivingDropsEvent event) {
        if (event.getEntity().getPersistentData().getBoolean("mk_nightmare")) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onXp(LivingExperienceDropEvent event) {
        if (event.getEntity().getPersistentData().getBoolean("mk_nightmare")) {
            event.setDroppedExperience(0);
        }
    }

    /** Clean up anything left over from a genjutsu that was interrupted by a restart. */
    @SubscribeEvent
    public static void onJoin(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) {
            return;
        }
        Entity entity = event.getEntity();
        if (entity instanceof Mob mob) {
            if (mob.getPersistentData().getBoolean("mk_entranced") && !GenjutsuManager.isTarget(mob.getUUID())) {
                mob.setNoAi(false);
                mob.getPersistentData().remove("mk_entranced");
            }
            if (mob.getPersistentData().getBoolean("mk_nightmare") && !GenjutsuManager.isSessionMob(mob.getUUID())) {
                event.setCanceled(true);
            }
            if (mob.getPersistentData().getBoolean("mk_decoy") && !GenjutsuManager.isSessionBody(mob.getUUID())) {
                event.setCanceled(true);
            }
        }
    }

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            GenjutsuManager.onLogin(player);
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            Abilities.stopSusanoo(player);
            GenjutsuManager.onLogout(player);
        }
    }

    @SubscribeEvent
    public static void onServerStarted(ServerStartedEvent event) {
        GenjutsuManager.clearStaleForcedChunks(event.getServer());
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        GenjutsuManager.endAll();
    }
}
