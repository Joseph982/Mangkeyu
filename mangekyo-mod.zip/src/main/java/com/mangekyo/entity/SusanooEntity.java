package com.mangekyo.entity;

import com.mangekyo.ability.Abilities;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraftforge.network.NetworkHooks;

import java.util.Optional;
import java.util.UUID;

/** Visual-only entity: the blue skeleton that wraps around its owner. Rendering is done client side. */
public class SusanooEntity extends Entity {
    private static final EntityDataAccessor<Optional<UUID>> OWNER =
            SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Integer> SWING =
            SynchedEntityData.defineId(SusanooEntity.class, EntityDataSerializers.INT);

    public SusanooEntity(EntityType<? extends SusanooEntity> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(OWNER, Optional.empty());
        this.entityData.define(SWING, 0);
    }

    public void setOwner(UUID id) {
        this.entityData.set(OWNER, Optional.ofNullable(id));
    }

    public UUID getOwnerId() {
        return this.entityData.get(OWNER).orElse(null);
    }

    public int getSwingTicks() {
        return this.entityData.get(SWING);
    }

    public void triggerSwing() {
        this.entityData.set(SWING, 10);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            return;
        }
        UUID ownerId = getOwnerId();
        Player owner = ownerId == null ? null : this.level().getPlayerByUUID(ownerId);
        if (owner == null || !Abilities.hasSusanoo(owner.getUUID()) || !owner.isAlive()) {
            this.discard();
            return;
        }
        this.setPos(owner.getX(), owner.getY(), owner.getZ());
        this.setYRot(owner.getYRot());
        int swing = this.entityData.get(SWING);
        if (swing > 0) {
            this.entityData.set(SWING, swing - 1);
        }
    }

    @Override
    public boolean shouldRenderAtSqrDistance(double distance) {
        return true;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
