package com.mangekyo.entity;

import com.mangekyo.genjutsu.GenjutsuManager;
import com.mangekyo.registry.ModSounds;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import org.joml.Vector3f;

import java.util.Optional;
import java.util.UUID;

/**
 * One class for every "person made of genjutsu": the caster's clones (staring, punching, fading, sword-wielding)
 * and the frozen body left behind in the overworld when a player is pulled into the genjutsu.
 */
public class ShadowCloneEntity extends PathfinderMob {
    public static final int MODE_STARE = 0;
    public static final int MODE_ATTACK = 1;
    public static final int MODE_FADE = 2;
    public static final int MODE_SWORD = 3;
    public static final int MODE_BODY = 4;
    public static final int MODE_WATCHER = 5;

    private static final DustParticleOptions BLACK = new DustParticleOptions(new Vector3f(0.04F, 0.04F, 0.04F), 2.2F);

    private static final DustParticleOptions RED_SLASH = new DustParticleOptions(new Vector3f(0.9F, 0.02F, 0.05F), 1.2F);
    private static final int SWING_LEN = 8;
    private static final int SLASH_TOTAL = 14;

    private static final EntityDataAccessor<Optional<UUID>> SKIN_OWNER =
            SynchedEntityData.defineId(ShadowCloneEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    /** Bumped every time the clone swings so clients can start the swing animation themselves. */
    private static final EntityDataAccessor<Integer> SWING_SEQ =
            SynchedEntityData.defineId(ShadowCloneEntity.class, EntityDataSerializers.INT);

    private int mode = MODE_STARE;
    private int modeTicks = 0;
    private int attackCooldown = 0;
    private UUID casterId = null;
    private UUID victimId = null;
    private Vec3 fadeTo = null;
    private int clientSeq = 0;
    private int clientSwingTicks = 0;
    private int slashPhase = -1;
    private int seenTicks = -1;
    private Vec3 slashHome = null;

    public ShadowCloneEntity(EntityType<? extends ShadowCloneEntity> type, Level level) {
        super(type, level);
        this.setNoAi(true);
        this.setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, 3.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(SKIN_OWNER, Optional.empty());
        this.entityData.define(SWING_SEQ, 0);
    }

    public UUID getSkinOwner() {
        return this.entityData.get(SKIN_OWNER).orElse(null);
    }

    public void setSkinOwner(UUID id) {
        this.entityData.set(SKIN_OWNER, Optional.ofNullable(id));
    }

    public void setCasterId(UUID id) {
        this.casterId = id;
    }

    public void setVictimId(UUID id) {
        this.victimId = id;
    }

    public int getMode() {
        return this.mode;
    }

    public void setMode(int newMode) {
        this.mode = newMode;
        this.modeTicks = 0;
        boolean still = newMode == MODE_STARE || newMode == MODE_SWORD || newMode == MODE_BODY
                || newMode == MODE_WATCHER;
        this.seenTicks = -1;
        this.setNoAi(still);
        this.getNavigation().stop();
        if (newMode == MODE_FADE) {
            pickFadeTarget();
        }
    }

    private Entity victimEntity() {
        if (this.victimId == null) {
            return null;
        }
        if (this.level() instanceof ServerLevel serverLevel) {
            return serverLevel.getEntity(this.victimId);
        }
        return null;
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            int seq = this.entityData.get(SWING_SEQ);
            if (seq != this.clientSeq) {
                this.clientSeq = seq;
                this.clientSwingTicks = SWING_LEN;
            } else if (this.clientSwingTicks > 0) {
                this.clientSwingTicks--;
            }
            return;
        }
        this.modeTicks++;
        if (this.attackCooldown > 0) {
            this.attackCooldown--;
        }
        Entity victim = victimEntity();
        switch (this.mode) {
            case MODE_STARE:
                if (victim != null) {
                    faceEntity(victim);
                }
                break;
            case MODE_SWORD:
                if (victim != null) {
                    faceEntity(victim);
                }
                tickSlash(victim);
                break;
            case MODE_WATCHER:
                if (victim != null) {
                    faceEntity(victim);
                    tickWatcher(victim);
                }
                break;
            case MODE_ATTACK:
                if (victim == null || this.modeTicks > 600) {
                    vanish(true);
                    return;
                }
                tickAttack(victim);
                break;
            case MODE_FADE:
                tickFade();
                break;
            default:
                break;
        }
    }

    private void faceEntity(Entity target) {
        double dx = target.getX() - this.getX();
        double dz = target.getZ() - this.getZ();
        double dy = target.getEyeY() - this.getEyeY();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        float pitch = (float) (-(Mth.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0D / Math.PI)));
        this.setYRot(yaw);
        this.setXRot(pitch);
        this.setYHeadRot(yaw);
        this.setYBodyRot(yaw);
        this.yRotO = yaw;
        this.xRotO = pitch;
        this.yHeadRotO = yaw;
        this.yBodyRotO = yaw;
    }

    private void tickAttack(Entity victim) {
        if (!(victim instanceof LivingEntity target)) {
            return;
        }
        if (this.tickCount % 10 == 0) {
            this.getNavigation().moveTo(target, 1.2D);
        }
        this.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (this.attackCooldown <= 0 && this.distanceToSqr(target) < 3.2D) {
            this.attackCooldown = 18;
            this.triggerSwing();
            GenjutsuManager.mentalDamage(target, this, 2.0F + this.random.nextFloat() * 1.5F, false);
        }
    }

    private void pickFadeTarget() {
        Entity victim = victimEntity();
        Vec3 away;
        if (victim == null) {
            away = new Vec3(this.random.nextDouble() - 0.5D, 0.0D, this.random.nextDouble() - 0.5D);
        } else {
            Vec3 diff = this.position().subtract(victim.position());
            away = new Vec3(diff.x, 0.0D, diff.z);
        }
        if (away.lengthSqr() < 1.0E-4D) {
            away = new Vec3(1.0D, 0.0D, 0.0D);
        }
        this.fadeTo = this.position().add(away.normalize().scale(12.0D));
    }

    private void tickFade() {
        if (this.fadeTo != null && this.tickCount % 10 == 0) {
            this.getNavigation().moveTo(this.fadeTo.x, this.fadeTo.y, this.fadeTo.z, 1.0D);
        }
        if (this.modeTicks > 70) {
            vanish(true);
        }
    }

    /**
     * The Watcher stands far away, motionless, staring. The moment the victim looks at it, a 2 second countdown
     * starts; when it ends the clone dissolves into black smoke.
     */
    private void tickWatcher(Entity victim) {
        if (this.seenTicks < 0) {
            if (victim instanceof LivingEntity living && isSeenBy(living)) {
                this.seenTicks = 0;
                if (victim instanceof ServerPlayer player) {
                    player.playNotifySound(ModSounds.GENJUTSU.get(), SoundSource.MASTER, 0.6F, 1.4F);
                }
            }
            return;
        }
        this.seenTicks++;
        if (this.seenTicks >= 40) {
            vanish(true);
        }
    }

    private boolean isSeenBy(LivingEntity viewer) {
        Vec3 look = viewer.getViewVector(1.0F).normalize();
        Vec3 toMe = this.getEyePosition().subtract(viewer.getEyePosition());
        double distance = toMe.length();
        if (distance < 1.0E-3D || distance > 120.0D) {
            return false;
        }
        double dot = look.dot(toMe.scale(1.0D / distance));
        return dot > 0.8D && viewer.hasLineOfSight(this);
    }

    /** Swing the sword arm (vanilla swing + our own synced counter so it always animates). */
    public void triggerSwing() {
        this.swing(InteractionHand.MAIN_HAND);
        this.entityData.set(SWING_SEQ, this.entityData.get(SWING_SEQ) + 1);
    }

    @Override
    public float getAttackAnim(float partialTick) {
        if (this.clientSwingTicks > 0) {
            float progress = (SWING_LEN - this.clientSwingTicks + partialTick) / SWING_LEN;
            return Mth.clamp(progress, 0.0F, 1.0F);
        }
        return super.getAttackAnim(partialTick);
    }

    /** Start one sword attack: lunge at the victim, slash, step back. */
    public void startSlash() {
        if (this.slashPhase < 0) {
            this.slashPhase = 0;
            this.slashHome = this.position();
        }
    }

    private void tickSlash(Entity victim) {
        if (this.slashPhase < 0 || this.slashHome == null) {
            return;
        }
        this.slashPhase++;
        double t = Math.min(1.0D, this.slashPhase / (double) SLASH_TOTAL);
        double lunge = Math.sin(t * Math.PI) * 1.7D;
        Vec3 dir = Vec3.ZERO;
        if (victim != null) {
            dir = new Vec3(victim.getX() - this.slashHome.x, 0.0D, victim.getZ() - this.slashHome.z);
            if (dir.lengthSqr() > 1.0E-4D) {
                dir = dir.normalize();
            }
        }
        this.setPos(this.slashHome.x + dir.x * lunge, this.slashHome.y, this.slashHome.z + dir.z * lunge);
        if (this.slashPhase == 5) {
            this.triggerSwing();
            slashHit(victim, dir);
        }
        if (this.slashPhase >= SLASH_TOTAL) {
            this.setPos(this.slashHome.x, this.slashHome.y, this.slashHome.z);
            this.slashPhase = -1;
        }
    }

    private void slashHit(Entity victim, Vec3 dir) {
        if (!(victim instanceof LivingEntity living) || !(this.level() instanceof ServerLevel sl)) {
            return;
        }
        GenjutsuManager.mentalDamage(living, this, 2.0F, true);
        double mx = living.getX();
        double my = living.getY() + living.getBbHeight() * 0.6D;
        double mz = living.getZ();
        sl.sendParticles(ParticleTypes.SWEEP_ATTACK, mx, my, mz, 0, 0.0D, 0.0D, 0.0D, 0.0D);
        sl.sendParticles(ParticleTypes.CRIT, mx, my, mz, 12, 0.3D, 0.3D, 0.3D, 0.3D);
        // a diagonal red streak across the victim so the cut is clearly visible
        double rx = -dir.z;
        double rz = dir.x;
        for (int i = 0; i <= 10; i++) {
            double k = i / 10.0D;
            double side = -0.8D + 1.6D * k;
            double up = 0.7D - 1.4D * k;
            sl.sendParticles(RED_SLASH, mx + rx * side, my + up, mz + rz * side, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        sl.playSound(null, mx, my, mz, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1.0F, 0.9F);
        sl.playSound(null, mx, my, mz, SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 0.8F, 1.1F);
    }

    /** Dissolve into black smoke. */
    public void vanish(boolean withSound) {
        if (this.level() instanceof ServerLevel serverLevel) {
            serverLevel.sendParticles(ParticleTypes.LARGE_SMOKE, this.getX(), this.getY() + 1.0D, this.getZ(),
                    30, 0.3D, 0.7D, 0.3D, 0.02D);
            serverLevel.sendParticles(BLACK, this.getX(), this.getY() + 1.0D, this.getZ(),
                    40, 0.35D, 0.8D, 0.35D, 0.01D);
            if (withSound) {
                serverLevel.playSound(null, this.getX(), this.getY(), this.getZ(),
                        ModSounds.CLONE_VANISH.get(), SoundSource.HOSTILE, 1.0F, 1.0F);
            }
        }
        this.discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.level().isClientSide) {
            return false;
        }
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            this.discard();
            return true;
        }
        Entity attacker = source.getEntity();
        if (attacker == null || this.mode == MODE_BODY) {
            return false;
        }
        if (attacker.getUUID().equals(this.casterId)) {
            return false;
        }
        this.vanish(true);
        return true;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
